/*
 * quadrature.h
 *
 *  Created on: May 3, 2017
 *      Author: frohro
 */

#ifndef QUADRATURE_H_
#define QUADRATURE_H_


void quadrature(unsigned long long freq, unsigned long long pll_freq);


#endif /* QUADRATURE_H_ */
