#ifndef PRINTF_H_
#define PRINTF_H_

void printf(char *, ...);

#endif /* PRINTF_H_ */
